Please describe the a concise description and fill out the details below. It will help others efficiently understand your request and get to an answer instead of repeated back and forth. Providing a [minimal, complete and verifiable example](https://stackoverflow.com/help/mcve) will further increase your chances that someone can help.

**Steps for Reproduction**

1. Visit [quilljs.com, jsfiddle.net, codepen.io]
2. Step Two
3. Step Three

**Expected behavior**:

**Actual behavior**:

**Platforms**:

Include browser, operating system and respective versions

**Version**:

Run `Quill.version` to find out
